import React, { useState } from 'react';
import { Heart, Upload, TrendingUp, MessageCircle, Clock, Smile, BarChart3 } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const WhatsAppCrushAnalyzer = () => {
  const [file, setFile] = useState(null);
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [userName, setUserName] = useState('');

  const parseWhatsAppChat = (text, userName) => {
    const lines = text.split('\n');
    const messages = [];
    const messageRegex = /^(\d{1,2}\/\d{1,2}\/\d{2,4}),?\s+(\d{1,2}:\d{2}(?::\d{2})?\s*(?:am|pm|AM|PM)?)\s*[-–]\s*([^:]+):\s*(.+)$/;
    
    for (let line of lines) {
      const match = line.match(messageRegex);
      if (match) {
        const [, date, time, sender, message] = match;
        messages.push({
          date: date.trim(),
          time: time.trim(),
          sender: sender.trim(),
          message: message.trim(),
          timestamp: parseDateTime(date.trim(), time.trim())
        });
      }
    }
    
    return messages;
  };

  const parseDateTime = (dateStr, timeStr) => {
    try {
      const [day, month, year] = dateStr.split('/').map(Number);
      const fullYear = year < 100 ? 2000 + year : year;
      
      let hours, minutes;
      const timeMatch = timeStr.match(/(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(am|pm|AM|PM)?/);
      
      if (timeMatch) {
        hours = parseInt(timeMatch[1]);
        minutes = parseInt(timeMatch[2]);
        const period = timeMatch[4];
        
        if (period && period.toLowerCase() === 'pm' && hours !== 12) {
          hours += 12;
        } else if (period && period.toLowerCase() === 'am' && hours === 12) {
          hours = 0;
        }
      }
      
      return new Date(fullYear, month - 1, day, hours || 0, minutes || 0);
    } catch (e) {
      return new Date();
    }
  };

  const calculateReplyTime = (messages, userName, otherPerson) => {
    const replyTimes = [];
    
    for (let i = 1; i < messages.length; i++) {
      if (messages[i].sender === otherPerson && messages[i-1].sender === userName) {
        const timeDiff = (messages[i].timestamp - messages[i-1].timestamp) / (1000 * 60);
        if (timeDiff > 0 && timeDiff < 1440) {
          replyTimes.push(timeDiff);
        }
      }
    }
    
    const avgReplyTime = replyTimes.length > 0 
      ? replyTimes.reduce((a, b) => a + b, 0) / replyTimes.length 
      : 30;
    
    let R = 0;
    if (avgReplyTime < 2) R = 25;
    else if (avgReplyTime < 10) R = 15;
    else if (avgReplyTime < 15) R = 10;
    else if (avgReplyTime < 30) R = 5;
    else R = -5;
    
    return { R, avgReplyTime };
  };

  const calculateEmojiUsage = (messages, otherPerson) => {
    const otherMessages = messages.filter(m => m.sender === otherPerson);
    const emojiRegex = /[\u{1F300}-\u{1F9FF}]|[\u{2600}-\u{26FF}]|[\u{2700}-\u{27BF}]|😀|😁|😂|😃|😄|😅|😆|😉|😊|😋|😎|😍|😘|🥰|😗|😙|😚|☺️|🙂|🤗|🤩|🤔|🤨|😐|😑|😶|🙄|😏|😣|😥|😮|🤐|😯|😪|😫|😴|😌|😛|😜|😝|🤤|😒|😓|😔|😕|🙃|🤑|😲|☹️|🙁|😖|😞|😟|😤|😢|😭|😦|😧|😨|😩|🤯|😬|😰|😱|🥵|🥶|😳|🤪|😵|😡|😠|🤬|😷|🤒|🤕|🤢|🤮|🤧|😇|🤠|🤡|🥳|🥴|🥺|🤥|🤫|🤭|🧐|🤓|❤️|💕|💖|💗|💓|💞|💘|💝|💟|♥️|💔|❣️|💋|👍|👎|👌|✌️|🤞|🤟|🤘|🤙|👈|👉|👆|👇|☝️|✋|🤚|🖐️|🖖|👋|🤝|💪|🙏|✍️|💅|🤳|💃|🕺|🎉|🎊|🎈|🎁|🏆|🥇|🥈|🥉|⭐|🌟|💫|✨|🔥|💯|😊|❤|💕|😂|🤣|☺|😉|😍|🥺|✨|🙈|🙊|🙉|💖|💗|💓|💞|💘|🌸|🌹|🌺|🌻|🌼|🌷|🥀|💐|🍀|🌈|⚡|💥|💦|💨|☀️|⭐|🌙|⛅|☁️|🌧️|⛈️|🌩️|❄️|☃️|⛄|🌬️|💨|🔥|💧|🌊/gu;
    
    const messagesWithEmoji = otherMessages.filter(m => emojiRegex.test(m.message)).length;
    const e = otherMessages.length > 0 ? messagesWithEmoji / otherMessages.length : 0;
    
    let E = 0;
    if (e > 0.5) E = 20;
    else if (e > 0.2) E = 15;
    else if (e > 0.1) E = 10;
    else if (e > 0.05) E = 5;
    
    return { E, emojiRatio: e };
  };

  const calculateMessageBalance = (messages, userName, otherPerson) => {
    const userMessages = messages.filter(m => m.sender === userName).length;
    const otherMessages = messages.filter(m => m.sender === otherPerson).length;
    const totalMessages = userMessages + otherMessages;
    
    const m = totalMessages > 0 ? otherMessages / totalMessages : 0;
    
    let M = 0;
    if (m > 0.45) M = 15;
    else if (m > 0.35) M = 10;
    else if (m > 0.25) M = 5;
    else M = -10;
    
    return { M, balance: m };
  };

  const calculateConsistency = (messages, otherPerson) => {
    const otherMessages = messages.filter(m => m.sender === otherPerson);
    
    if (messages.length === 0) return { C: 0, avgMessagesPerDay: 0 };
    
    const firstDate = messages[0].timestamp;
    const lastDate = messages[messages.length - 1].timestamp;
    const daysDiff = Math.max(1, (lastDate - firstDate) / (1000 * 60 * 60 * 24));
    
    const avgMessagesPerDay = otherMessages.length / daysDiff;
    const d = Math.min(1, avgMessagesPerDay / 50);
    
    let C = 0;
    if (d > 0.8) C = 15;
    else if (d > 0.5) C = 10;
    else if (d > 0.3) C = 5;
    
    return { C, avgMessagesPerDay, consistency: d };
  };

  const getQuote = (score) => {
    if (score >= 95) return "💖 The stars have aligned! This is pure magic! ✨";
    else if (score >= 85) return "💕 Someone's totally into you! The vibes are incredible! 🌟";
    else if (score >= 75) return "💗 There's definitely something special brewing here! 🦋";
    else if (score >= 65) return "💓 Strong feelings detected! They're invested in you! 🌸";
    else if (score >= 55) return "💞 Good signs! They enjoy talking to you! 🌈";
    else if (score >= 45) return "💘 There's potential here! Keep the conversation flowing! 🌺";
    else if (score >= 35) return "💝 Friendly vibes! Maybe they need a little push? 🌻";
    else return "💙 Starting slow, but every love story has a beginning! 🌱";
  };

  const getScoreLevel = (score) => {
    if (score >= 85) return "🔥 ON FIRE";
    else if (score >= 70) return "💖 STRONG CONNECTION";
    else if (score >= 55) return "💕 INTERESTED";
    else if (score >= 40) return "💓 FRIENDLY";
    else return "💙 STARTING OUT";
  };

  const analyzeChat = (text, userName) => {
    const messages = parseWhatsAppChat(text, userName);
    
    if (messages.length === 0) {
      alert('Could not parse chat. Please check the file format.');
      return null;
    }
    
    const participants = [...new Set(messages.map(m => m.sender))];
    const otherPerson = participants.find(p => p !== userName) || participants[0];
    
    const { R, avgReplyTime } = calculateReplyTime(messages, userName, otherPerson);
    const { E, emojiRatio } = calculateEmojiUsage(messages, otherPerson);
    const { M, balance } = calculateMessageBalance(messages, userName, otherPerson);
    const { C, avgMessagesPerDay, consistency } = calculateConsistency(messages, otherPerson);
    
    const finalScore = Math.max(0, Math.min(100, 50 + R + E + M + C));
    
    const chartData = [
      { name: 'Reply Time', value: R, max: 25, color: '#ff69b4' },
      { name: 'Emoji Usage', value: E, max: 20, color: '#ff1493' },
      { name: 'Message Balance', value: M, max: 15, color: '#db7093' },
      { name: 'Consistency', value: C, max: 15, color: '#ffb6c1' }
    ];
    
    return {
      score: finalScore,
      otherPerson,
      totalMessages: messages.length,
      R, E, M, C,
      avgReplyTime,
      emojiRatio,
      balance,
      avgMessagesPerDay,
      consistency,
      chartData,
      quote: getQuote(finalScore),
      level: getScoreLevel(finalScore)
    };
  };

  const handleFileUpload = async (e) => {
    const uploadedFile = e.target.files[0];
    if (!uploadedFile) return;
    
    if (!userName.trim()) {
      alert('Please enter your name as it appears in the chat!');
      return;
    }
    
    setLoading(true);
    const reader = new FileReader();
    
    reader.onload = (event) => {
      const text = event.target.result;
      const analysis = analyzeChat(text, userName.trim());
      if (analysis) {
        setResults(analysis);
      }
      setLoading(false);
    };
    
    reader.readAsText(uploadedFile);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-rose-50 to-pink-100 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8 mt-8">
          <div className="flex items-center justify-center mb-4">
            <Heart className="w-12 h-12 text-pink-500 animate-pulse" fill="currentColor" />
          </div>
          <h1 className="text-4xl font-bold text-pink-600 mb-2">WhatsApp Crush Analyzer</h1>
          <p className="text-pink-400 text-lg">Decode the signals and find out if they're into you! 💕</p>
        </div>

        {!results && (
          <div className="bg-white rounded-3xl shadow-2xl p-8 border-4 border-pink-200">
            <div className="mb-6">
              <label className="block text-pink-600 font-semibold mb-2 text-lg">
                Your Name (as it appears in chat)
              </label>
              <input
                type="text"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                placeholder="Enter your WhatsApp name..."
                className="w-full px-4 py-3 border-2 border-pink-300 rounded-xl focus:outline-none focus:border-pink-500 text-gray-700"
              />
            </div>

            <div className="border-4 border-dashed border-pink-300 rounded-2xl p-12 text-center hover:border-pink-400 transition-all cursor-pointer bg-pink-50">
              <input
                type="file"
                accept=".txt"
                onChange={handleFileUpload}
                className="hidden"
                id="file-upload"
              />
              <label htmlFor="file-upload" className="cursor-pointer">
                <Upload className="w-16 h-16 mx-auto text-pink-400 mb-4" />
                <p className="text-xl font-semibold text-pink-600 mb-2">Upload WhatsApp Chat</p>
                <p className="text-pink-400">Click to select your exported .txt file</p>
              </label>
            </div>

            {loading && (
              <div className="text-center mt-6">
                <div className="animate-spin rounded-full h-12 w-12 border-4 border-pink-300 border-t-pink-600 mx-auto"></div>
                <p className="text-pink-500 mt-4 font-semibold">Analyzing your chat... 💭</p>
              </div>
            )}
          </div>
        )}

        {results && (
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-pink-500 to-rose-500 rounded-3xl shadow-2xl p-8 text-white text-center">
              <h2 className="text-2xl font-bold mb-2">Analysis Complete!</h2>
              <p className="text-pink-100 mb-4">Chatting with: <span className="font-bold">{results.otherPerson}</span></p>
              
              <div className="bg-white/20 backdrop-blur rounded-2xl p-6 mb-4">
                <div className="text-7xl font-bold mb-2">{results.score}%</div>
                <div className="text-2xl font-semibold mb-2">{results.level}</div>
                <div className="text-lg italic">"{results.quote}"</div>
              </div>
            </div>

            <div className="bg-white rounded-3xl shadow-xl p-8 border-4 border-pink-200">
              <h3 className="text-2xl font-bold text-pink-600 mb-6 flex items-center">
                <TrendingUp className="mr-2" /> Parameter Analysis
              </h3>
              
              <div className="h-80 mb-8">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={[
                    { param: 'Reply Time', score: results.R, max: 25 },
                    { param: 'Emoji Usage', score: results.E, max: 20 },
                    { param: 'Balance', score: results.M, max: 15 },
                    { param: 'Consistency', score: results.C, max: 15 }
                  ]}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#ffc0cb" />
                    <XAxis dataKey="param" stroke="#ec4899" />
                    <YAxis stroke="#ec4899" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#fff', 
                        border: '2px solid #ec4899',
                        borderRadius: '10px'
                      }}
                    />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="score" 
                      stroke="#ec4899" 
                      strokeWidth={3}
                      dot={{ fill: '#ec4899', r: 6 }}
                      name="Score"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="max" 
                      stroke="#ffc0cb" 
                      strokeWidth={2}
                      strokeDasharray="5 5"
                      dot={{ fill: '#ffc0cb', r: 4 }}
                      name="Max Possible"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-pink-50 rounded-xl p-4 border-2 border-pink-200">
                  <div className="flex items-center mb-2">
                    <Clock className="w-5 h-5 text-pink-500 mr-2" />
                    <span className="font-semibold text-pink-700">Reply Time</span>
                  </div>
                  <div className="text-2xl font-bold text-pink-600">{results.R} pts</div>
                  <div className="text-sm text-pink-500">Avg: {results.avgReplyTime.toFixed(1)} min</div>
                </div>

                <div className="bg-pink-50 rounded-xl p-4 border-2 border-pink-200">
                  <div className="flex items-center mb-2">
                    <Smile className="w-5 h-5 text-pink-500 mr-2" />
                    <span className="font-semibold text-pink-700">Emoji Usage</span>
                  </div>
                  <div className="text-2xl font-bold text-pink-600">{results.E} pts</div>
                  <div className="text-sm text-pink-500">{(results.emojiRatio * 100).toFixed(1)}% of messages</div>
                </div>

                <div className="bg-pink-50 rounded-xl p-4 border-2 border-pink-200">
                  <div className="flex items-center mb-2">
                    <MessageCircle className="w-5 h-5 text-pink-500 mr-2" />
                    <span className="font-semibold text-pink-700">Message Balance</span>
                  </div>
                  <div className="text-2xl font-bold text-pink-600">{results.M} pts</div>
                  <div className="text-sm text-pink-500">{(results.balance * 100).toFixed(1)}% their msgs</div>
                </div>

                <div className="bg-pink-50 rounded-xl p-4 border-2 border-pink-200">
                  <div className="flex items-center mb-2">
                    <BarChart3 className="w-5 h-5 text-pink-500 mr-2" />
                    <span className="font-semibold text-pink-700">Consistency</span>
                  </div>
                  <div className="text-2xl font-bold text-pink-600">{results.C} pts</div>
                  <div className="text-sm text-pink-500">{results.avgMessagesPerDay.toFixed(1)} msgs/day</div>
                </div>
              </div>

              <div className="mt-6 text-center">
                <button
                  onClick={() => setResults(null)}
                  className="bg-gradient-to-r from-pink-500 to-rose-500 text-white px-8 py-3 rounded-full font-semibold hover:from-pink-600 hover:to-rose-600 transition-all shadow-lg"
                >
                  Analyze Another Chat 💕
                </button>
              </div>
            </div>

            <div className="bg-white rounded-3xl shadow-xl p-6 border-4 border-pink-200 text-center">
              <p className="text-pink-500 text-sm">
                Total Messages Analyzed: <span className="font-bold">{results.totalMessages}</span>
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default WhatsAppCrushAnalyzer;