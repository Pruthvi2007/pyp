import React, { useState } from 'react';
import { Heart, Upload, TrendingUp, MessageCircle, Clock, Smile, BarChart3, CheckCircle, AlertTriangle, Lightbulb, Phone, Users, Calendar, Sparkles, Rocket, CompassIcon, MessageSquare, RefreshCw, Lock } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface Message {
  date: string;
  time: string;
  sender: string;
  message: string;
  timestamp: Date;
}

interface AnalysisResults {
  score: number;
  otherPerson: string;
  totalMessages: number;
  R: number;
  E: number;
  M: number;
  C: number;
  avgReplyTime: number;
  emojiRatio: number;
  balance: number;
  avgMessagesPerDay: number;
  consistency: number;
  chartData: Array<{ name: string; value: number; max: number; color: string }>;
  quote: string;
  level: string;
}

interface Flag {
  title: string;
  description: string;
}

interface SuggestionCard {
  icon: JSX.Element;
  title: string;
  description: string;
  actions: string[];
}

interface PersonalizedSuggestions {
  title: string;
  icon: JSX.Element;
  cards: SuggestionCard[];
}

const WhatsAppCrushAnalyzer = () => {
  const [file, setFile] = useState<File | null>(null);
  const [results, setResults] = useState<AnalysisResults | null>(null);
  const [loading, setLoading] = useState(false);
  const [userName, setUserName] = useState('');

  const parseWhatsAppChat = (text: string, userName: string): Message[] => {
    const lines = text.split('\n');
    const messages: Message[] = [];
    const messageRegex = /^(\d{1,2}\/\d{1,2}\/\d{2,4}),?\s+(\d{1,2}:\d{2}(?::\d{2})?\s*(?:am|pm|AM|PM)?)\s*[-–]\s*([^:]+):\s*(.+)$/;
    
    for (let line of lines) {
      const match = line.match(messageRegex);
      if (match) {
        const [, date, time, sender, message] = match;
        messages.push({
          date: date.trim(),
          time: time.trim(),
          sender: sender.trim(),
          message: message.trim(),
          timestamp: parseDateTime(date.trim(), time.trim())
        });
      }
    }
    
    return messages;
  };

  const parseDateTime = (dateStr: string, timeStr: string): Date => {
    try {
      const [day, month, year] = dateStr.split('/').map(Number);
      const fullYear = year < 100 ? 2000 + year : year;
      
      let hours, minutes;
      const timeMatch = timeStr.match(/(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(am|pm|AM|PM)?/);
      
      if (timeMatch) {
        hours = parseInt(timeMatch[1]);
        minutes = parseInt(timeMatch[2]);
        const period = timeMatch[4];
        
        if (period && period.toLowerCase() === 'pm' && hours !== 12) {
          hours += 12;
        } else if (period && period.toLowerCase() === 'am' && hours === 12) {
          hours = 0;
        }
      }
      
      return new Date(fullYear, month - 1, day, hours || 0, minutes || 0);
    } catch (e) {
      return new Date();
    }
  };

  const calculateReplyTime = (messages: Message[], userName: string, otherPerson: string) => {
    const replyTimes: number[] = [];
    
    for (let i = 1; i < messages.length; i++) {
      if (messages[i].sender === otherPerson && messages[i-1].sender === userName) {
        const timeDiff = (messages[i].timestamp.getTime() - messages[i-1].timestamp.getTime()) / (1000 * 60);
        if (timeDiff > 0 && timeDiff < 1440) {
          replyTimes.push(timeDiff);
        }
      }
    }
    
    const avgReplyTime = replyTimes.length > 0 
      ? replyTimes.reduce((a, b) => a + b, 0) / replyTimes.length 
      : 30;
    
    let R = 0;
    if (avgReplyTime < 2) R = 25;
    else if (avgReplyTime < 10) R = 15;
    else if (avgReplyTime < 15) R = 10;
    else if (avgReplyTime < 30) R = 5;
    else R = -5;
    
    return { R, avgReplyTime };
  };

  const calculateEmojiUsage = (messages: Message[], otherPerson: string) => {
    const otherMessages = messages.filter((m: Message) => m.sender === otherPerson);
    const emojiRegex = /😀|😁|😂|😃|😄|😅|😆|😉|😊|😋|😎|😍|😘|🥰|😗|😙|😚|☺️|🙂|🤗|🤩|🤔|🤨|😐|😑|😶|🙄|😏|😣|😥|😮|🤐|😯|😪|😫|😴|😌|😛|😜|😝|🤤|😒|😓|😔|😕|🙃|🤑|😲|☹️|🙁|😖|😞|😟|😤|😢|😭|😦|😧|😨|😩|🤯|😬|😰|😱|🥵|🥶|😳|🤪|😵|😡|😠|🤬|😷|🤒|🤕|🤢|🤮|🤧|😇|🤠|🤡|🥳|🥴|🥺|🤥|🤫|🤭|🧐|🤓|❤️|💕|💖|💗|💓|💞|💘|💝|💟|♥️|💔|❣️|💋|👍|👎|👌|✌️|🤞|🤟|🤘|🤙|👈|👉|👆|👇|☝️|✋|🤚|🖐️|🖖|👋|🤝|💪|🙏|✍️|💅|🤳|💃|🕺|🎉|🎊|🎈|🎁|🏆|🥇|🥈|🥉|⭐|🌟|💫|✨|🔥|💯|❤|☺|🙈|🙊|🙉|🌸|🌹|🌺|🌻|🌼|🌷|🥀|💐|🍀|🌈|⚡|💥|💦|💨|☀️|🌙|⛅|☁️|🌧️|⛈️|🌩️|❄️|☃️|⛄|🌬️|💧|🌊/;
    
    const messagesWithEmoji = otherMessages.filter((m: Message) => emojiRegex.test(m.message)).length;
    const e = otherMessages.length > 0 ? messagesWithEmoji / otherMessages.length : 0;
    
    let E = 0;
    if (e > 0.5) E = 20;
    else if (e > 0.2) E = 15;
    else if (e > 0.1) E = 10;
    else if (e > 0.05) E = 5;
    
    return { E, emojiRatio: e };
  };

  const calculateMessageBalance = (messages: Message[], userName: string, otherPerson: string) => {
    const userMessages = messages.filter((m: Message) => m.sender === userName).length;
    const otherMessages = messages.filter((m: Message) => m.sender === otherPerson).length;
    const totalMessages = userMessages + otherMessages;
    
    const m = totalMessages > 0 ? otherMessages / totalMessages : 0;
    
    let M = 0;
    if (m > 0.45) M = 15;
    else if (m > 0.35) M = 10;
    else if (m > 0.25) M = 5;
    else M = -10;
    
    return { M, balance: m };
  };

  const calculateConsistency = (messages: Message[], otherPerson: string) => {
    const otherMessages = messages.filter((m: Message) => m.sender === otherPerson);
    
    if (messages.length === 0) return { C: 0, avgMessagesPerDay: 0, consistency: 0 };
    
    const firstDate = messages[0].timestamp;
    const lastDate = messages[messages.length - 1].timestamp;
    const daysDiff = Math.max(1, (lastDate.getTime() - firstDate.getTime()) / (1000 * 60 * 60 * 24));
    
    const avgMessagesPerDay = otherMessages.length / daysDiff;
    const d = Math.min(1, avgMessagesPerDay / 50);
    
    let C = 0;
    if (d > 0.8) C = 15;
    else if (d > 0.5) C = 10;
    else if (d > 0.3) C = 5;
    
    return { C, avgMessagesPerDay, consistency: d };
  };

  const getQuote = (score: number): string => {
    if (score >= 90) return "🔥 The stars have aligned! This is pure magic! ✨";
    else if (score >= 80) return "💕 Someone's totally into you! The vibes are incredible! 🌟";
    else if (score >= 70) return "💗 There's definitely something special brewing here! 🦋";
    else if (score >= 60) return "💓 Strong feelings detected! They're invested in you! 🌸";
    else if (score >= 50) return "💞 Good signs! Interest is building! 🌈";
    else if (score >= 40) return "💘 Friendly vibes! Maybe they need a little push? 🌺";
    else if (score >= 30) return "💝 Early days, but lots of potential! 🌻";
    else return "🤝 Great friendship foundation! 🌱";
  };

  const getScoreLevel = (score: number): string => {
    if (score >= 90) return "🔥 Totally Smitten";
    else if (score >= 80) return "💕 Clearly Interested";
    else if (score >= 70) return "💖 Good Chemistry";
    else if (score >= 60) return "💗 Definitely Likes You";
    else if (score >= 50) return "💙 Warming Up";
    else if (score >= 40) return "💚 Friendly Vibes";
    else if (score >= 30) return "🌱 Just Getting Started";
    else return "🤝 Just Friends";
  };

  const getGreenFlags = (results: AnalysisResults): Flag[] => {
    const flags: Flag[] = [];
    
    if (results.avgReplyTime < 10) {
      flags.push({
        title: "Quick Responses",
        description: `They reply within ${results.avgReplyTime.toFixed(1)} minutes on average - you're clearly a priority!`
      });
    }

    if (results.emojiRatio > 0.3) {
      flags.push({
        title: "High Emoji Usage",
        description: `${(results.emojiRatio * 100).toFixed(0)}% emoji rate shows they're comfortable being expressive with you`
      });
    }

    if (results.balance > 0.4) {
      flags.push({
        title: "Balanced Conversation",
        description: "Nearly equal message split - they're just as engaged as you are!"
      });
    }

    if (results.avgMessagesPerDay > 15) {
      flags.push({
        title: "Daily Contact",
        description: "Consistent daily messaging shows you're on their mind regularly"
      });
    }

    if (results.R > 10) {
      flags.push({
        title: "Prioritizes Your Messages",
        description: "Their quick response pattern shows genuine interest in talking to you"
      });
    }

    return flags;
  };

  const getWarningFlags = (results: AnalysisResults): Flag[] => {
    const flags: Flag[] = [];
    
    flags.push({
      title: "Timing Patterns",
      description: "Pay attention to when they're most responsive - evening chats might be more promising"
    });

    flags.push({
      title: "Topic Depth",
      description: "Keep conversations meaningful - share personal stories and ask thoughtful questions"
    });

    flags.push({
      title: "Initiative Balance",
      description: "Make sure you're both starting conversations - it should feel natural from both sides"
    });

    flags.push({
      title: "Energy Matching",
      description: "Their enthusiasm level should match or exceed yours over time"
    });

    return flags;
  };

  const getPersonalizedSuggestions = (score: number): PersonalizedSuggestions => {
    if (score >= 80) {
      return {
        title: "They're Into You! Here's Your Game Plan",
        icon: <Heart className="w-8 h-8 pulse-heart" />,
        cards: [
          {
            icon: <Calendar className="w-8 h-8" />,
            title: "Ask Them Out",
            description: "The signals are clear - make your move!",
            actions: [
              'Be direct: "I really enjoy talking to you. Want to go out this weekend?"',
              "Suggest a specific activity you've discussed together",
              "Show confidence - they're waiting for you to take the lead!"
            ]
          },
          {
            icon: <Heart className="w-8 h-8" />,
            title: "Express Interest",
            description: "Let them know you feel it too!",
            actions: [
              "Compliment them genuinely and specifically",
              "Show you pay attention to details they share",
              "Use flirty but respectful language"
            ]
          },
          {
            icon: <Rocket className="w-8 h-8" />,
            title: "Keep the Momentum",
            description: "Don't let this connection fade!",
            actions: [
              "Maintain consistent communication",
              "Plan regular video calls or meetups",
              "Be authentic - they like the real you!"
            ]
          }
        ]
      };
    } else if (score >= 50) {
      return {
        title: "Your Personalized Action Plan",
        icon: <Sparkles className="w-8 h-8" />,
        cards: [
          {
            icon: <Phone className="w-8 h-8" />,
            title: "Level Up the Connection",
            description: "The chemistry is there - time to deepen it!",
            actions: [
              "Suggest a voice call to hear their voice and create a stronger bond",
              "Share voice notes - they're personal and show extra effort",
              "Send photos of your day to build visual connection"
            ]
          },
          {
            icon: <MessageSquare className="w-8 h-8" />,
            title: "Conversation Strategies",
            description: "Keep the spark alive with engaging topics!",
            actions: [
              "Ask about their passions and dreams - go deeper than surface chat",
              "Share vulnerable moments to build emotional intimacy",
              "Use playful teasing and inside jokes to create your own language"
            ]
          },
          {
            icon: <Calendar className="w-8 h-8" />,
            title: "Next Steps",
            description: "Time to make your move!",
            actions: [
              'Casually suggest hanging out - "We should grab coffee sometime"',
              "Plan a low-pressure activity you'd both enjoy",
              "Be genuine about wanting to spend time together IRL"
            ]
          }
        ]
      };
    } else {
      return {
        title: "Finding Your Path",
        icon: <CompassIcon className="w-8 h-8" />,
        cards: [
          {
            icon: <Heart className="w-8 h-8" />,
            title: "Read the Signals",
            description: "Understand where you stand!",
            actions: [
              "Notice if they initiate conversations or only reply",
              "Pay attention to their response depth and timing",
              "Be honest with yourself about mutual interest"
            ]
          },
          {
            icon: <Users className="w-8 h-8" />,
            title: "Value the Friendship",
            description: "Great friendships are precious too!",
            actions: [
              "Appreciate the connection for what it is",
              "Don't force romantic feelings where they aren't",
              "Good friends can become amazing support systems"
            ]
          },
          {
            icon: <Rocket className="w-8 h-8" />,
            title: "Keep Options Open",
            description: "Don't put all eggs in one basket!",
            actions: [
              "Continue meeting new people and expanding your circle",
              "Focus on personal growth and self-improvement",
              "The right person will make their interest clear"
            ]
          }
        ]
      };
    }
  };

  const conversationStarters = [
    {
      message: "What's something you're really passionate about lately?",
      description: "Opens up deeper conversation about their interests",
      color: "from-purple-50 to-pink-50 border-purple-200"
    },
    {
      message: "If you could travel anywhere right now, where would you go?",
      description: "Fun hypothetical that reveals their dreams",
      color: "from-pink-50 to-rose-50 border-pink-200"
    },
    {
      message: "What's the best thing that happened to you this week?",
      description: "Shows you care about their happiness",
      color: "from-rose-50 to-red-50 border-rose-200"
    },
    {
      message: "I was thinking about [shared interest] - have you tried [related thing]?",
      description: "Builds on common ground you've established",
      color: "from-red-50 to-orange-50 border-red-200"
    },
    {
      message: "What's your idea of a perfect weekend?",
      description: "Gives insight into their lifestyle preferences",
      color: "from-indigo-50 to-purple-50 border-indigo-200"
    },
    {
      message: "I need your opinion on something...",
      description: "Makes them feel valued and involved",
      color: "from-blue-50 to-indigo-50 border-blue-200"
    }
  ];

  const analyzeChat = (text: string, userName: string): AnalysisResults | null => {
    const messages = parseWhatsAppChat(text, userName);
    
    if (messages.length === 0) {
      alert('Could not parse chat. Please check the file format.');
      return null;
    }
    
    const participants = Array.from(new Set(messages.map((m: Message) => m.sender)));
    const otherPerson = participants.find((p: string) => p !== userName) || participants[0];
    
    const { R, avgReplyTime } = calculateReplyTime(messages, userName, otherPerson);
    const { E, emojiRatio } = calculateEmojiUsage(messages, otherPerson);
    const { M, balance } = calculateMessageBalance(messages, userName, otherPerson);
    const { C, avgMessagesPerDay, consistency } = calculateConsistency(messages, otherPerson);
    
    const finalScore = Math.max(0, Math.min(100, 50 + R + E + M + C));
    
    const chartData = [
      { name: 'Reply Time', value: R, max: 25, color: '#ff69b4' },
      { name: 'Emoji Usage', value: E, max: 20, color: '#ff1493' },
      { name: 'Message Balance', value: M, max: 15, color: '#db7093' },
      { name: 'Consistency', value: C, max: 15, color: '#ffb6c1' }
    ];
    
    return {
      score: finalScore,
      otherPerson,
      totalMessages: messages.length,
      R, E, M, C,
      avgReplyTime,
      emojiRatio,
      balance,
      avgMessagesPerDay,
      consistency,
      chartData,
      quote: getQuote(finalScore),
      level: getScoreLevel(finalScore)
    };
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = e.target.files?.[0];
    if (!uploadedFile) return;
    
    if (!userName.trim()) {
      alert('Please enter your name as it appears in the chat!');
      return;
    }
    
    setLoading(true);
    const reader = new FileReader();
    
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const analysis = analyzeChat(text, userName.trim());
      if (analysis) {
        setResults(analysis);
      }
      setLoading(false);
    };
    
    reader.readAsText(uploadedFile);
  };

  const scoreRanges = [
    { min: 90, max: 100, emoji: "🔥", label: "Totally Smitten", desc: "They're head over heels!", color: "from-red-50 to-pink-50 border-red-400" },
    { min: 80, max: 89, emoji: "💕", label: "Clearly Interested", desc: "Strong romantic signals", color: "from-pink-50 to-rose-50 border-pink-400" },
    { min: 70, max: 79, emoji: "💖", label: "Good Chemistry", desc: "Something special is there", color: "from-purple-50 to-pink-50 border-purple-400" },
    { min: 60, max: 69, emoji: "💗", label: "Definitely Likes You", desc: "They're invested in you", color: "from-indigo-50 to-purple-50 border-indigo-400" },
    { min: 50, max: 59, emoji: "💙", label: "Warming Up", desc: "Interest is building", color: "from-blue-50 to-indigo-50 border-blue-400" },
    { min: 40, max: 49, emoji: "💚", label: "Friendly Vibes", desc: "Good friends, maybe more?", color: "from-teal-50 to-blue-50 border-teal-400" },
    { min: 30, max: 39, emoji: "🌱", label: "Just Getting Started", desc: "Early days, lots of potential", color: "from-green-50 to-teal-50 border-green-400" },
    { min: 0, max: 29, emoji: "🤝", label: "Just Friends", desc: "Platonic connection", color: "from-gray-50 to-green-50 border-gray-400" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-rose-50 to-pink-100 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8 mt-8">
          <div className="flex items-center justify-center mb-4">
            <Heart className="w-12 h-12 text-pink-500 animate-pulse pulse-heart" fill="currentColor" />
          </div>
          <h1 className="text-5xl font-bold gradient-text mb-2">WhatsApp Crush Analyzer</h1>
          <p className="text-pink-400 text-lg">Decode the signals and find out if they're into you! 💕</p>
        </div>

        {!results && (
          <div className="bg-white rounded-3xl shadow-2xl p-8 border-4 border-pink-200">
            <div className="mb-6">
              <label className="block text-pink-600 font-semibold mb-2 text-lg">
                Your Name (as it appears in chat)
              </label>
              <input
                type="text"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                placeholder="Enter your WhatsApp name..."
                className="w-full px-4 py-3 border-2 border-pink-300 rounded-xl focus:outline-none focus:border-pink-500 text-gray-700"
                data-testid="input-username"
              />
            </div>

            <div className="border-4 border-dashed border-pink-300 rounded-2xl p-12 text-center hover:border-pink-400 transition-all cursor-pointer bg-pink-50">
              <input
                type="file"
                accept=".txt"
                onChange={handleFileUpload}
                className="hidden"
                id="file-upload"
                data-testid="input-file"
              />
              <label htmlFor="file-upload" className="cursor-pointer">
                <Upload className="w-16 h-16 mx-auto text-pink-400 mb-4" />
                <p className="text-xl font-semibold text-pink-600 mb-2">Upload WhatsApp Chat</p>
                <p className="text-pink-400">Click to select your exported .txt file</p>
              </label>
            </div>

            {loading && (
              <div className="text-center mt-6">
                <div className="animate-spin rounded-full h-12 w-12 border-4 border-pink-300 border-t-pink-600 mx-auto"></div>
                <p className="text-pink-500 mt-4 font-semibold">Analyzing your chat... 💭</p>
              </div>
            )}
          </div>
        )}

        {results && (
          <div className="space-y-8">
            {/* Main Score Card */}
            <div className="bg-gradient-to-r from-pink-500 to-rose-500 rounded-3xl shadow-2xl p-8 text-white text-center">
              <h2 className="text-2xl font-bold mb-2">Analysis Complete!</h2>
              <p className="text-pink-100 mb-6">Chatting with: <span className="font-bold text-white">{results.otherPerson}</span></p>
              
              <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-8 mb-4">
                <div className="text-8xl font-bold mb-3" data-testid="text-score">{results.score}</div>
                <div className="text-3xl font-semibold mb-3" data-testid="text-level">{results.level}</div>
                <div className="text-xl italic" data-testid="text-quote">"{results.quote}"</div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div className="bg-white/10 rounded-xl p-4">
                  <div className="text-2xl font-bold" data-testid="text-total-messages">{results.totalMessages}</div>
                  <div className="text-pink-100">Total Messages</div>
                </div>
                <div className="bg-white/10 rounded-xl p-4">
                  <div className="text-2xl font-bold" data-testid="text-avg-reply-time">{results.avgReplyTime.toFixed(1)} min</div>
                  <div className="text-pink-100">Avg Reply Time</div>
                </div>
                <div className="bg-white/10 rounded-xl p-4">
                  <div className="text-2xl font-bold" data-testid="text-emoji-usage">{(results.emojiRatio * 100).toFixed(0)}%</div>
                  <div className="text-pink-100">Emoji Usage</div>
                </div>
                <div className="bg-white/10 rounded-xl p-4">
                  <div className="text-2xl font-bold" data-testid="text-message-balance">{(results.balance * 100).toFixed(0)}%</div>
                  <div className="text-pink-100">Message Balance</div>
                </div>
              </div>
            </div>

            {/* Score Level Guide */}
            <div className="bg-white rounded-3xl shadow-xl p-8 border-4 border-pink-200">
              <h3 className="text-2xl font-bold text-pink-600 mb-6 flex items-center">
                <TrendingUp className="mr-3" /> Understanding Your Score
              </h3>
              
              <div className="space-y-3">
                {scoreRanges.map((range, index) => (
                  <div 
                    key={index}
                    className={`flex items-center justify-between p-4 bg-gradient-to-r ${range.color} rounded-xl border-l-4 ${
                      results.score >= range.min && results.score <= range.max ? 'ring-2 ring-pink-400 ring-opacity-50' : ''
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{range.emoji}</span>
                      <div>
                        <span className="font-semibold text-gray-800">{range.label}</span>
                        <span className="text-sm text-gray-500 ml-2">({range.min}-{range.max})</span>
                      </div>
                    </div>
                    <span className="text-xs text-gray-500 hidden md:block">{range.desc}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Metric Insights */}
            <div className="bg-white rounded-3xl shadow-xl p-8 border-4 border-pink-200">
              <h3 className="text-2xl font-bold text-pink-600 mb-6 flex items-center">
                <Lightbulb className="mr-3" /> What Your Metrics Mean
              </h3>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6 border border-purple-200">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center">
                        <Clock className="text-white text-xl" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-800">Reply Time</h4>
                        <p className="text-sm text-purple-600">{results.avgReplyTime.toFixed(1)} minutes</p>
                      </div>
                    </div>
                    <div className="text-2xl font-bold text-purple-600">+{results.R}</div>
                  </div>
                  <div className="w-full bg-purple-200 rounded-full h-2 mb-3">
                    <div 
                      className="bg-purple-500 h-2 rounded-full progress-bar" 
                      style={{ width: `${Math.max(10, (results.R + 5) * 4)}%` }}
                    ></div>
                  </div>
                  <p className="text-sm text-gray-600">Quick replies show they prioritize your conversation. Under 10 minutes is a great sign they're eager to talk!</p>
                </div>

                <div className="bg-gradient-to-br from-pink-50 to-rose-50 rounded-2xl p-6 border border-pink-200">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-pink-500 rounded-full flex items-center justify-center">
                        <Smile className="text-white text-xl" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-800">Emoji Usage</h4>
                        <p className="text-sm text-pink-600">{(results.emojiRatio * 100).toFixed(0)}% of messages</p>
                      </div>
                    </div>
                    <div className="text-2xl font-bold text-pink-600">+{results.E}</div>
                  </div>
                  <div className="w-full bg-pink-200 rounded-full h-2 mb-3">
                    <div 
                      className="bg-pink-500 h-2 rounded-full progress-bar" 
                      style={{ width: `${Math.max(10, results.E * 5)}%` }}
                    ></div>
                  </div>
                  <p className="text-sm text-gray-600">Emojis add warmth and personality! High usage indicates they're comfortable expressing emotions with you.</p>
                </div>

                <div className="bg-gradient-to-br from-rose-50 to-red-50 rounded-2xl p-6 border border-rose-200">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-rose-500 rounded-full flex items-center justify-center">
                        <MessageCircle className="text-white text-xl" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-800">Message Balance</h4>
                        <p className="text-sm text-rose-600">{(results.balance * 100).toFixed(0)}% their messages</p>
                      </div>
                    </div>
                    <div className="text-2xl font-bold text-rose-600">+{results.M}</div>
                  </div>
                  <div className="w-full bg-rose-200 rounded-full h-2 mb-3">
                    <div 
                      className="bg-rose-500 h-2 rounded-full progress-bar" 
                      style={{ width: `${Math.max(10, (results.M + 10) * 5)}%` }}
                    ></div>
                  </div>
                  <p className="text-sm text-gray-600">Equal participation shows mutual interest. A balanced conversation is key to building connection!</p>
                </div>

                <div className="bg-gradient-to-br from-red-50 to-orange-50 rounded-2xl p-6 border border-red-200">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center">
                        <BarChart3 className="text-white text-xl" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-800">Consistency</h4>
                        <p className="text-sm text-red-600">{results.avgMessagesPerDay.toFixed(1)} msgs/day</p>
                      </div>
                    </div>
                    <div className="text-2xl font-bold text-red-600">+{results.C}</div>
                  </div>
                  <div className="w-full bg-red-200 rounded-full h-2 mb-3">
                    <div 
                      className="bg-red-500 h-2 rounded-full progress-bar" 
                      style={{ width: `${Math.max(10, results.C * 6.67)}%` }}
                    ></div>
                  </div>
                  <p className="text-sm text-gray-600">Regular messaging shows you're on their mind. Consistent daily chats indicate genuine interest!</p>
                </div>
              </div>
            </div>

            {/* Green Flags & Warning Signs */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-white rounded-3xl shadow-xl p-8 border-4 border-green-200">
                <h3 className="text-2xl font-bold text-green-600 mb-6 flex items-center">
                  <CheckCircle className="mr-3" /> Green Flags 🎯
                </h3>
                
                <div className="space-y-4">
                  {getGreenFlags(results).map((flag, index) => (
                    <div key={index} className="flex items-start gap-3 p-4 bg-green-50 rounded-xl border border-green-200">
                      <Heart className="text-green-500 mt-1 w-5 h-5 flex-shrink-0" />
                      <div>
                        <h4 className="font-semibold text-gray-800">{flag.title}</h4>
                        <p className="text-sm text-gray-600">{flag.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-3xl shadow-xl p-8 border-4 border-amber-200">
                <h3 className="text-2xl font-bold text-amber-600 mb-6 flex items-center">
                  <AlertTriangle className="mr-3" /> Things to Watch ⚠️
                </h3>
                
                <div className="space-y-4">
                  {getWarningFlags(results).map((flag, index) => (
                    <div key={index} className="flex items-start gap-3 p-4 bg-amber-50 rounded-xl border border-amber-200">
                      <AlertTriangle className="text-amber-500 mt-1 w-5 h-5 flex-shrink-0" />
                      <div>
                        <h4 className="font-semibold text-gray-800">{flag.title}</h4>
                        <p className="text-sm text-gray-600">{flag.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Personalized Suggestions */}
            {(() => {
              const suggestions = getPersonalizedSuggestions(results.score);
              return (
                <div className="bg-gradient-to-br from-pink-500 via-rose-500 to-pink-600 rounded-3xl shadow-2xl p-8 text-white">
                  <h3 className="text-3xl font-bold mb-3 flex items-center">
                    {suggestions.icon} {suggestions.title}
                  </h3>
                  <p className="text-pink-100 mb-8">Based on your {results.score}% compatibility score, here's what we recommend:</p>
                  
                  <div className="grid md:grid-cols-3 gap-6">
                    {suggestions.cards.map((card, index) => (
                      <div key={index} className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 card-hover">
                        <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mb-4 mx-auto">
                          {card.icon}
                        </div>
                        <h4 className="text-xl font-semibold mb-3 text-center">{card.title}</h4>
                        <p className="text-pink-100 text-sm text-center mb-4">{card.description}</p>
                        <ul className="space-y-2 text-sm">
                          {card.actions.map((action, actionIndex) => (
                            <li key={actionIndex} className="flex items-start gap-2">
                              <CheckCircle className="mt-1 flex-shrink-0 w-4 h-4" />
                              <span>{action}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })()}

            {/* Conversation Starters */}
            <div className="bg-white rounded-3xl shadow-xl p-8 border-4 border-pink-200">
              <h3 className="text-2xl font-bold text-pink-600 mb-6 flex items-center">
                <MessageSquare className="mr-3" /> Conversation Starters to Try
              </h3>
              
              <div className="grid md:grid-cols-2 gap-4">
                {conversationStarters.map((starter, index) => (
                  <div key={index} className={`bg-gradient-to-r ${starter.color} rounded-xl p-5 border`}>
                    <div className="flex items-start gap-3">
                      <MessageSquare className="text-purple-400 text-xl mt-1 flex-shrink-0" />
                      <div>
                        <p className="text-gray-700 font-medium mb-2">"{starter.message}"</p>
                        <p className="text-sm text-gray-500">{starter.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Final CTA */}
            <div className="bg-gradient-to-r from-pink-600 to-rose-600 rounded-3xl shadow-2xl p-8 text-center text-white">
              <Rocket className="text-5xl mb-4 mx-auto" />
              <h3 className="text-3xl font-bold mb-3">Ready to Make Your Move?</h3>
              <p className="text-pink-100 text-lg mb-6 max-w-2xl mx-auto">Remember, the best relationships are built on authenticity, communication, and mutual respect. Trust the process and be yourself!</p>
              <button 
                onClick={() => setResults(null)}
                className="bg-white text-pink-600 px-8 py-4 rounded-full font-semibold text-lg hover:bg-pink-50 transition-all transform hover:scale-105 shadow-lg flex items-center gap-2 mx-auto"
                data-testid="button-analyze-another"
              >
                <RefreshCw className="w-5 h-5" /> Analyze Another Chat
              </button>
            </div>

            {/* Privacy Notice */}
            <div className="text-center text-gray-500 text-sm">
              <p className="flex items-center justify-center gap-2">
                <Lock className="w-4 h-4" /> Your privacy matters: All analysis happens locally in your browser. No data is stored or sent to servers.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default WhatsAppCrushAnalyzer;
