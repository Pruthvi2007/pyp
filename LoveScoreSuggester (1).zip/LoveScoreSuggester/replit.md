# WhatsApp Crush Analyzer

## Overview

A web application that analyzes WhatsApp chat exports to evaluate relationship dynamics and provide insights. Users upload their WhatsApp chat files, and the application calculates various metrics (response time, emoji usage, message balance, consistency) to generate a "crush score" along with personalized suggestions for improving communication.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build Tool**
- React with TypeScript for type safety and component-based architecture
- Vite as the build tool and development server for fast HMR (Hot Module Replacement)
- Wouter for lightweight client-side routing (alternative to React Router)

**UI Component System**
- shadcn/ui component library built on Radix UI primitives
- Tailwind CSS for styling with custom design tokens and CSS variables
- "New York" style variant with neutral color scheme and custom pink/romance-themed color palette
- Comprehensive component set including forms, dialogs, charts, and data visualization components

**State Management & Data Fetching**
- TanStack Query (React Query) for server state management and data fetching
- Custom query client with configured defaults (no refetch on window focus, infinite stale time)
- Centralized API request handling with credential-based authentication support

**Key Design Decisions**
- Client-side chat parsing: All WhatsApp chat analysis happens in the browser for privacy (no server-side data processing)
- Recharts library for data visualization and analytics display
- Form validation using React Hook Form with Zod schema validation
- Toast notifications for user feedback

### Backend Architecture

**Server Framework**
- Express.js as the HTTP server framework
- TypeScript with ESNext module system for modern JavaScript features
- Development and production build pipelines using tsx (dev) and esbuild (production)

**API Structure**
- RESTful API design with `/api` prefix for all application routes
- Request/response logging middleware with JSON response capture
- Raw body access for webhook/special payload handling
- Static file serving for production builds

**Development Environment**
- Vite integration for development with middleware mode
- Hot module replacement through Vite dev server
- Custom error overlay plugin for runtime error handling
- Replit-specific plugins for development tools (cartographer, dev banner) when running in Replit environment

### Data Storage

**Database Architecture**
- PostgreSQL as the primary database (configured via DATABASE_URL environment variable)
- Drizzle ORM for type-safe database queries and schema management
- Neon Database serverless driver for PostgreSQL connectivity

**Schema Design**
- Users table with UUID primary keys (using PostgreSQL's `gen_random_uuid()`)
- Zod schema validation for insert operations
- Shared schema definitions between client and server (`shared/schema.ts`)

**Storage Strategy**
- In-memory storage implementation (MemStorage) for development/testing
- Interface-based storage design (IStorage) allowing easy swapping of storage implementations
- CRUD operations abstracted through storage interface

**Key Architectural Decision**
The application currently uses an in-memory storage implementation despite having Drizzle/PostgreSQL configured. This suggests the database integration is prepared but not yet fully implemented. The storage interface pattern allows seamless migration from in-memory to database-backed storage without changing application code.

### External Dependencies

**UI & Styling Libraries**
- Radix UI: Accessible, unstyled UI primitives for all interactive components
- Tailwind CSS with autoprefixer for responsive styling
- class-variance-authority and clsx for dynamic className management
- Lucide React for iconography

**Data Visualization**
- Recharts for charts and analytics visualization
- Embla Carousel for carousel/slider functionality

**Form & Validation**
- React Hook Form for form state management
- Zod for runtime type validation and schema definition
- @hookform/resolvers for Zod integration with React Hook Form

**Database & ORM**
- Drizzle ORM for database operations
- Drizzle Kit for migrations management
- @neondatabase/serverless for PostgreSQL connectivity
- drizzle-zod for generating Zod schemas from Drizzle schemas

**Session Management**
- connect-pg-simple for PostgreSQL session storage (configured but may not be actively used with current in-memory storage)

**Build & Development Tools**
- Vite with React plugin for frontend builds
- esbuild for server-side production bundling
- TypeScript for type checking across the stack
- Replit-specific plugins for enhanced development experience

**Routing & Navigation**
- Wouter for lightweight client-side routing (< 2KB alternative to React Router)

**Date Handling**
- date-fns for date manipulation and formatting in chat analysis